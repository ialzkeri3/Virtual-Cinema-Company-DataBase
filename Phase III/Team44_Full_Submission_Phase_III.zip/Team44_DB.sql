CREATE DATABASE  IF NOT EXISTS `team44` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `team44`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: team44
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`username`),
  CONSTRAINT `FK_Admin_User_username` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('cool_class4400');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `company` (
  `comName` varchar(50) NOT NULL,
  PRIMARY KEY (`comName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES ('4400 Theater Company'),('AI Theater Company'),('Awesome Theater Company'),('EZ Theater Company');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customer` (
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`username`),
  CONSTRAINT `FK_Customer_User_username` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('calcultron'),('calcultron2'),('calcwizard'),('clarinetbeast'),('cool_class4400'),('DNAhelix'),('does2Much'),('eeqmcsquare'),('entropyRox'),('fullMetal'),('georgep'),('ilikemoney$$'),('imready'),('isthisthekrustykrab'),('notFullMetal'),('programerAAL'),('RitzLover28'),('thePiGuy3.14'),('theScienceGuy');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercreditcard`
--

DROP TABLE IF EXISTS `customercreditcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customercreditcard` (
  `creditCardNum` char(16) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`creditCardNum`),
  KEY `FK_CustomerCreditCard_Customer_username_idx` (`username`),
  CONSTRAINT `FK_CustomerCreditCard_Customer_username` FOREIGN KEY (`username`) REFERENCES `customer` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercreditcard`
--

LOCK TABLES `customercreditcard` WRITE;
/*!40000 ALTER TABLE `customercreditcard` DISABLE KEYS */;
INSERT INTO `customercreditcard` VALUES ('1111111111000000','calcultron'),('1111111100000000','calcultron2'),('1111111110000000','calcultron2'),('1111111111100000','calcwizard'),('2222222222000000','cool_class4400'),('2220000000000000','DNAhelix'),('2222222200000000','does2Much'),('2222222222222200','eeqmcsquare'),('2222222222200000','entropyRox'),('2222222222220000','entropyRox'),('1100000000000000','fullMetal'),('1111111111110000','georgep'),('1111111111111000','georgep'),('1111111111111100','georgep'),('1111111111111110','georgep'),('1111111111111111','georgep'),('2222222222222220','ilikemoney$$'),('2222222222222222','ilikemoney$$'),('9000000000000000','ilikemoney$$'),('1111110000000000','imready'),('1110000000000000','isthisthekrustykrab'),('1111000000000000','isthisthekrustykrab'),('1111100000000000','isthisthekrustykrab'),('1000000000000000','notFullMetal'),('2222222000000000','programerAAL'),('3333333333333300','RitzLover28'),('2222222220000000','thePiGuy3.14'),('2222222222222000','theScienceGuy');
/*!40000 ALTER TABLE `customercreditcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customerviewmovie`
--

DROP TABLE IF EXISTS `customerviewmovie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customerviewmovie` (
  `creditCardNum` char(16) NOT NULL,
  `thName` varchar(50) NOT NULL,
  `comName` varchar(50) NOT NULL,
  `movName` varchar(50) NOT NULL,
  `movReleaseDate` date NOT NULL,
  `movPlayDate` date NOT NULL,
  PRIMARY KEY (`creditCardNum`,`thName`,`comName`,`movName`,`movReleaseDate`,`movPlayDate`),
  KEY `FK_CustomerViewMovie_MoviePlay_thName,comName,movReleaseDate_idx` (`thName`,`comName`,`movName`,`movReleaseDate`,`movPlayDate`),
  CONSTRAINT `FK_CustomerViewMovie_CustomerCreditCard_creditCardNum` FOREIGN KEY (`creditCardNum`) REFERENCES `customercreditcard` (`creditCardNum`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_CustomerViewMovie_MoviePlay_PrettyMuchTheWholeThing` FOREIGN KEY (`thName`, `comName`, `movName`, `movReleaseDate`, `movPlayDate`) REFERENCES `movieplay` (`thName`, `comName`, `movName`, `movReleaseDate`, `movPlayDate`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customerviewmovie`
--

LOCK TABLES `customerviewmovie` WRITE;
/*!40000 ALTER TABLE `customerviewmovie` DISABLE KEYS */;
INSERT INTO `customerviewmovie` VALUES ('1111111111111111','Cinema Star','4400 Theater Company','How to Train Your Dragon','2010-03-21','2010-04-02'),('1111111111111111','Main Movies','EZ Theater Company','How to Train Your Dragon','2010-03-21','2010-03-22'),('1111111111111111','Main Movies','EZ Theater Company','How to Train Your Dragon','2010-03-21','2010-03-23'),('1111111111111100','Star Movies','EZ Theater Company','How to Train Your Dragon','2010-03-21','2010-03-25');
/*!40000 ALTER TABLE `customerviewmovie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `employee` (
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`username`),
  CONSTRAINT `FK_Employee_User_username` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES ('calcultron'),('entropyRox'),('fatherAI'),('georgep'),('ghcghc'),('imbatman'),('manager1'),('manager2'),('manager3'),('manager4'),('radioactivePoRa');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `manager` (
  `username` varchar(50) NOT NULL,
  `comName` varchar(50) NOT NULL,
  `manStreet` varchar(50) NOT NULL,
  `manCity` varchar(50) NOT NULL,
  `manState` enum('AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') NOT NULL,
  `manZipcode` int(5) NOT NULL,
  PRIMARY KEY (`username`),
  KEY `FK_Manager_Employee_username_idx` (`username`),
  KEY `FK_Manager_Company_comName_idx` (`comName`),
  CONSTRAINT `FK_Manager_Company_comName` FOREIGN KEY (`comName`) REFERENCES `company` (`comName`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `FK_Manager_Employee_username` FOREIGN KEY (`username`) REFERENCES `employee` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES ('calcultron','EZ Theater Company','123 Peachtree St','Atlanta','GA',30308),('entropyRox','4400 Theater Company','200 Cool Place','San Francisco','CA',94016),('fatherAI','EZ Theater Company','456 Main Street','New York','NY',10001),('georgep','4400 Theater Company','10 Pearl Dr','Seattle','WA',98105),('ghcghc','AI Theater Company','100 Pi St','Pallet Town','KS',31415),('imbatman','Awesome Theater Company','800 Color Dr','Austin','TX',78653),('manager1','4400 Theater Company','123 Ferst Drive','Atlanta','GA',30332),('manager2','AI Theater Company','456 Ferst Drive','Atlanta','GA',30332),('manager3','4400 Theater Company','789 Ferst Drive','Atlanta','GA',30332),('manager4','4400 Theater Company','000 Ferst Drive','Atlanta','GA',30332),('radioactivePoRa','4400 Theater Company','100 Blu St','Sunnyvale','CA',94088);
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `movie` (
  `movName` varchar(50) NOT NULL,
  `movReleaseDate` date NOT NULL,
  `duration` int(11) NOT NULL,
  PRIMARY KEY (`movName`,`movReleaseDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES ('4400 The Movie','2019-08-12',130),('Avengers: Endgame','2019-04-26',181),('Calculus Returns: A ML Story','2019-09-19',314),('George P Burdell\'s Life Story','1927-08-12',100),('Georgia Tech The Movie','1985-08-13',100),('How to Train Your Dragon','2010-03-21',98),('Spaceballs','1987-06-24',96),('Spider-Man: Into the Spider-Verse','2018-12-01',117),('The First Pokemon Movie','1998-07-19',75),('The King\'s Speech','2010-11-26',119);
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movieplay`
--

DROP TABLE IF EXISTS `movieplay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `movieplay` (
  `thName` varchar(50) NOT NULL,
  `comName` varchar(50) NOT NULL,
  `movName` varchar(50) NOT NULL,
  `movReleaseDate` date NOT NULL,
  `movPlayDate` date NOT NULL,
  PRIMARY KEY (`thName`,`comName`,`movName`,`movReleaseDate`,`movPlayDate`),
  KEY `FK_MoviePlay_Movie_movName_idx` (`movName`,`movReleaseDate`),
  CONSTRAINT `FK_MoviePlay_Movie_movName,movReleaseDate` FOREIGN KEY (`movName`, `movReleaseDate`) REFERENCES `movie` (`movName`, `movReleaseDate`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_MoviePlay_Theater_thname,comName` FOREIGN KEY (`thName`, `comName`) REFERENCES `theater` (`thName`, `comName`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movieplay`
--

LOCK TABLES `movieplay` WRITE;
/*!40000 ALTER TABLE `movieplay` DISABLE KEYS */;
INSERT INTO `movieplay` VALUES ('ABC Theater','Awesome Theater Company','4400 The Movie','2019-08-12','2019-10-12'),('Cinema Star','4400 Theater Company','4400 The Movie','2019-08-12','2019-09-12'),('Star Movies','EZ Theater Company','4400 The Movie','2019-08-12','2019-08-12'),('ML Movies','AI Theater Company','Calculus Returns: A ML Story','2019-09-19','2019-10-10'),('ML Movies','AI Theater Company','Calculus Returns: A ML Story','2019-09-19','2019-12-30'),('Cinema Star','4400 Theater Company','George P Burdell\'s Life Story','1927-08-12','2010-05-20'),('Main Movies','EZ Theater Company','George P Burdell\'s Life Story','1927-08-12','2019-07-14'),('Main Movies','EZ Theater Company','George P Burdell\'s Life Story','1927-08-12','2019-10-22'),('ABC Theater','Awesome Theater Company','Georgia Tech The Movie','1985-08-13','1985-08-13'),('Cinema Star','4400 Theater Company','Georgia Tech The Movie','1985-08-13','2019-09-30'),('Cinema Star','4400 Theater Company','How to Train Your Dragon','2010-03-21','2010-04-02'),('Main Movies','EZ Theater Company','How to Train Your Dragon','2010-03-21','2010-03-22'),('Main Movies','EZ Theater Company','How to Train Your Dragon','2010-03-21','2010-03-23'),('Star Movies','EZ Theater Company','How to Train Your Dragon','2010-03-21','2010-03-25'),('Cinema Star','4400 Theater Company','Spaceballs','1987-06-24','2000-02-02'),('Main Movies','EZ Theater Company','Spaceballs','1987-06-24','1999-06-24'),('ML Movies','AI Theater Company','Spaceballs','1987-06-24','2010-04-02'),('ML Movies','AI Theater Company','Spaceballs','1987-06-24','2023-01-23'),('ML Movies','AI Theater Company','Spider-Man: Into the Spider-Verse','2018-12-01','2019-09-30'),('ABC Theater','Awesome Theater Company','The First Pokemon Movie','1998-07-19','2018-07-19'),('Cinema Star','4400 Theater Company','The King\'s Speech','2010-11-26','2019-12-20'),('Main Movies','EZ Theater Company','The King\'s Speech','2010-11-26','2019-12-20');
/*!40000 ALTER TABLE `movieplay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theater`
--

DROP TABLE IF EXISTS `theater`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `theater` (
  `thName` varchar(50) NOT NULL,
  `comName` varchar(50) NOT NULL,
  `capacity` int(11) NOT NULL,
  `thStreet` varchar(50) NOT NULL,
  `thCity` varchar(50) NOT NULL,
  `thState` enum('AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') NOT NULL,
  `thZipCode` int(5) NOT NULL,
  `manUsername` varchar(50) NOT NULL,
  PRIMARY KEY (`thName`,`comName`),
  UNIQUE KEY `manUsername_UNIQUE` (`manUsername`),
  KEY `FK_Theater_Company_comName_idx` (`comName`),
  CONSTRAINT `FK_Theater_Company_comName` FOREIGN KEY (`comName`) REFERENCES `company` (`comName`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `FK_Theater_Manager_usernam` FOREIGN KEY (`manUsername`) REFERENCES `manager` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theater`
--

LOCK TABLES `theater` WRITE;
/*!40000 ALTER TABLE `theater` DISABLE KEYS */;
INSERT INTO `theater` VALUES ('ABC Theater','Awesome Theater Company',5,'880 Color Dr','Austin','TX',73301,'imbatman'),('Cinema Star','4400 Theater Company',4,'100 Cool Place','San Francisco','CA',94016,'entropyRox'),('Jonathan\'s Movies','4400 Theater Company',2,'67 Pearl Dr','Seattle','WA',98101,'georgep'),('Main Movies','EZ Theater Company',3,'123 Main St','New York','NY',10001,'fatherAI'),('ML Movies','AI Theater Company',3,'314 Pi St','Pallet Town','KS',31415,'ghcghc'),('Star Movies','4400 Theater Company',5,'4400 Rocks Ave','Boulder','CA',80301,'radioactivePoRa'),('Star Movies','EZ Theater Company',2,'745 GT St','Atlanta','GA',30332,'calcultron');
/*!40000 ALTER TABLE `theater` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `user` (
  `username` varchar(50) NOT NULL,
  `status` enum('Approved','Declined','Pending') NOT NULL DEFAULT 'Pending',
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userType` enum('User','Customer','Employee','Employee, Customer') NOT NULL DEFAULT 'User',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('calcultron','Approved','Dwight','Schrute','333333333','Employee, Customer'),('calcultron2','Approved','Jim','Halpert','444444444','Customer'),('calcwizard','Approved','Isaac','Newton','222222222','Customer'),('clarinetbeast','Declined','Squidward','Tentacles','999999999','Customer'),('cool_class4400','Approved','A. TA','Washere','333333333','Employee, Customer'),('DNAhelix','Approved','Rosalind','Franklin','777777777','Customer'),('does2Much','Approved','Carl','Gauss','1212121212','Customer'),('eeqmcsquare','Approved','Albert','Einstein','111111110','Customer'),('entropyRox','Approved','Claude','Shannon','999999999','Employee, Customer'),('fatherAI','Approved','Alan','Turing','222222222','Employee'),('fullMetal','Approved','Edward','Elric','111111100','Customer'),('gdanger','Declined','Gary','Danger','555555555','User'),('georgep','Approved','George P.','Burdell','111111111','Employee, Customer'),('ghcghc','Approved','Grace','Hopper','666666666','Employee'),('ilikemoney$$','Approved','Eugene','Krabs','111111110','Customer'),('imbatman','Approved','Bruce','Wayne','666666666','Employee'),('imready','Approved','Spongebob','Squarepants','777777777','Customer'),('isthisthekrustykrab','Approved','Patrick','Star','888888888','Customer'),('manager1','Approved','Manager','One','1122112211','Employee'),('manager2','Approved','Manager','Two','3131313131','Employee'),('manager3','Approved','Three','Three','8787878787','Employee'),('manager4','Approved','Four','Four','5755555555','Employee'),('notFullMetal','Approved','Alphonse','Elric','111111100','Customer'),('programerAAL','Approved','Ada','Lovelace','3131313131','Customer'),('radioactivePoRa','Approved','Marie','Curie','1313131313','Employee'),('RitzLover28','Approved','Abby','Normal','444444444','Customer'),('smith_j','Pending','John','Smith','333333333','User'),('texasStarKarate','Declined','Sandy','Cheeks','111111110','User'),('thePiGuy3.14','Approved','Archimedes','Syracuse','1111111111','Customer'),('theScienceGuy','Approved','Bill','Nye','999999999','Customer');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uservisittheater`
--

DROP TABLE IF EXISTS `uservisittheater`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `uservisittheater` (
  `visitID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `thName` varchar(50) NOT NULL,
  `comName` varchar(50) NOT NULL,
  `visitDate` date NOT NULL,
  PRIMARY KEY (`visitID`),
  KEY `FK_UserVisitTheater_Theater_thName,comName_idx` (`thName`,`comName`),
  KEY `FK_UserVisitTheater_User_username_idx` (`username`),
  CONSTRAINT `FK_UserVisitTheater_Theater_thName,comName` FOREIGN KEY (`thName`, `comName`) REFERENCES `theater` (`thName`, `comName`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `FK_UserVisitTheater_User_username` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uservisittheater`
--

LOCK TABLES `uservisittheater` WRITE;
/*!40000 ALTER TABLE `uservisittheater` DISABLE KEYS */;
INSERT INTO `uservisittheater` VALUES (1,'georgep','Main Movies','EZ Theater Company','2010-03-22'),(2,'calcwizard','Main Movies','EZ Theater Company','2010-03-22'),(3,'calcwizard','Star Movies','EZ Theater Company','2010-03-25'),(4,'imready','Star Movies','EZ Theater Company','2010-03-25'),(5,'calcwizard','ML Movies','AI Theater Company','2010-03-20');
/*!40000 ALTER TABLE `uservisittheater` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'team44'
--

--
-- Dumping routines for database 'team44'
--
/*!50003 DROP PROCEDURE IF EXISTS `admin_approve_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_approve_user`(IN i_username VARCHAR(50))
BEGIN
	UPDATE user SET status='Approved' WHERE username=i_username;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_create_mov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_create_mov`(IN i_movName VARCHAR(50), IN i_movDuration INT(11), i_movReleaseDate DATE)
BEGIN
	INSERT INTO movie(movName, movReleaseDate, duration) VALUES (i_movName, i_movReleaseDate, i_movDuration);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_create_theater` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_create_theater`(IN i_thName VARCHAR(50), IN i_comName VARCHAR(50), IN i_thStreet VARCHAR(50), IN i_thCity VARCHAR(50), IN i_thState CHAR(2), IN i_thZipcode CHAR(5), IN i_capacity INT(11), IN i_managerusername VARCHAR(50))
BEGIN
	IF i_thName IN (SELECT thName FROM theater WHERE comName=i_comName) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='This Company Already Has A Theater With This Name';
	ELSE IF i_managerusername NOT IN (SELECT username FROM employee) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='This Manager Is Not Registered';
	ELSE IF (i_managerusername, 1) IN (SELECT manUsername, COUNT(manUsername) from theater GROUP BY manUsername) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='This Manager Already Manages a Theater';
	ELSE
		INSERT INTO theater(thName, comName, capacity, thStreet, thCity, thState, thZipCode, manUsername) VALUES (i_thName, i_comName, i_capacity, i_thStreet, i_thCity, i_thState, i_thZipcode, i_managerusername);
    END IF;
    END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_decline_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_decline_user`(IN i_username VARCHAR(50))
BEGIN
	IF 'Approved' = (SELECT status FROM user WHERE username=i_username) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='This User Has Already Been Approved';
	ELSE
		UPDATE user SET status='Declined' WHERE username=i_username;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_filter_company` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_filter_company`(i_comName VARCHAR(50), i_minCity INT(11), i_maxCity INT(11), i_minTheater INT(11), i_maxTheater INT(11), i_minEmployee INT(11), i_maxEmployee INT(11), i_sortBy ENUM('','comName', 'numCityCover', 'numTheater', 'numEmployee'),  i_sortDirection ENUM('','DESC', 'ASC'))
BEGIN
	DROP TABLE IF EXISTS AdFilterCom;
	IF NOT (i_sortBy='NumCityCover' OR i_sortBy='NumTheater' OR i_sortBy='NumEmployee') THEN
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY (CASE WHEN (i_sortBy='' AND i_sortDirection='') THEN comName END) DESC,
				 (CASE WHEN (i_sortBy='' AND i_sortDirection='ASC') THEN comName END) ASC,
				 (CASE WHEN (i_sortBy='' AND i_sortDirection='DESC') THEN comName END) DESC,
				 (CASE WHEN (i_sortBy='comName' AND i_sortDirection='') THEN comName END) DESC,
				 (CASE WHEN (i_sortBy='comName' AND i_sortDirection='ASC') THEN comName END) ASC,
				 (CASE WHEN (i_sortBy='comName' AND i_sortDirection='DESC') THEN comName END) DESC;
	ELSE IF i_sortBy='NumCityCover' AND (i_sortDirection='' or i_sortDirection='DESC') THEN
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY NumCityCover DESC;
	ELSE IF i_sortBy='NumCityCover' AND (i_sortDirection='ASC') THEN
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY NumCityCover ASC;
	ELSE IF i_sortBy='NumTheater' AND (i_sortDirection='' or i_sortDirection='DESC') THEN
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY NumTheater DESC;
	ELSE IF i_sortBy='NumTheater' AND (i_sortDirection='ASC') THEN
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY NumTheater ASC;
	ELSE IF i_sortBy='NumEmployee' AND (i_sortDirection='' or i_sortDirection='DESC') THEN
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY NumEmployee DESC;
	ELSE
		CREATE TABLE AdFilterCom
		SELECT comName, COUNT(DISTINCT(thCity)) as NumCityCover, COUNT(DISTINCT(thStreet)) as NumTheater, COUNT(DISTINCT(username)) as NumEmployee
		FROM manager NATURAL JOIN theater
		GROUP BY comName
		HAVING
			(i_comName='ALL' OR i_comName='' OR comName=i_comName) AND
			(i_minCity IS NULL OR i_minCity<=NumCityCover) AND
			(i_maxCity IS NULL OR i_maxCity>=NumCityCover) AND
			(i_minTheater IS NULL OR i_minTheater<=NumTheater) AND
			(i_maxTheater IS NULL OR i_maxTheater>=NumTheater) AND
			(i_minEmployee IS NULL OR i_minEmployee<=NumEmployee) AND
			(i_maxEmployee IS NULL OR i_maxEmployee>=NumEmployee)
		ORDER BY NumEmployee ASC;
	END IF;
    END IF;
    END IF;
    END IF;
    END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_filter_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_filter_user`(i_username VARCHAR(50), i_status ENUM('ALL','Approved', 'Pending', 'Declined'), i_sortBy ENUM('','username', 'creditCardCount', 'userType', 'status'), i_sortDirection ENUM('','DESC', 'ASC'))
BEGIN
	IF NOT i_sortBy='creditCardCount' THEN
		DROP TABLE IF EXISTS AdFilterUser;
		CREATE TABLE AdFilterUser
		SELECT user.username, count(creditCardNum) as creditCardCount,CONCAT(IF(customer.username IS NOT NULL AND employee.username IS NOT NULL, 'CustomerManager',''),IF(customer.username IS NOT NULL AND employee.username IS NULL AND admin.username IS NULL, 'Customer',''),IF(customer.username IS NOT NULL AND admin.username IS NOT NULL, 'CustomerAdmin',''),IF(user.userType='User', 'User',''),IF(customer.username IS NULL AND employee.username IS NOT NULL, 'Manager',''),IF(customer.username IS NULL AND admin.username IS NOT NULL, 'Admin','')) AS userType, status
		FROM user LEFT JOIN customercreditcard on user.username=customercreditcard.username LEFT JOIN employee ON user.username=employee.username LEFT JOIN admin ON user.username=admin.username LEFT JOIN customer ON user.username=customer.username
        WHERE (i_username='' OR user.username=i_username) AND (i_status='ALL' OR status=i_status)
		GROUP BY user.username
		ORDER BY (CASE WHEN (i_sortBy='' AND i_sortDirection='') THEN user.username END) DESC,
				 (CASE WHEN (i_sortBy='' AND i_sortDirection='ASC') THEN user.username END) ASC,
				 (CASE WHEN (i_sortBy='' AND i_sortDirection='DESC') THEN user.username END) DESC,
				 (CASE WHEN (i_sortBy='username' AND i_sortDirection='') THEN user.username END) DESC,
				 (CASE WHEN (i_sortBy='username' AND i_sortDirection='ASC') THEN user.username END) ASC,
				 (CASE WHEN (i_sortBy='username' AND i_sortDirection='DESC') THEN user.username END) DESC,
				 (CASE WHEN (i_sortBy='userType' AND i_sortDirection='') THEN userType END) DESC,
				 (CASE WHEN (i_sortBy='userType' AND i_sortDirection='ASC') THEN userType END) ASC,
				 (CASE WHEN (i_sortBy='userType' AND i_sortDirection='DESC') THEN userType END) DESC,
				 (CASE WHEN (i_sortBy='status' AND i_sortDirection='') THEN status END) DESC,
				 (CASE WHEN (i_sortBy='status' AND i_sortDirection='ASC') THEN status END) ASC,
				 (CASE WHEN (i_sortBy='status' AND i_sortDirection='DESC') THEN status END) DESC;
	ELSE IF i_sortBy='creditCardCount' AND (i_sortDirection='' OR i_sortDirection='DESC') THEN
		DROP TABLE IF EXISTS AdFilterUser;
		CREATE TABLE AdFilterUser
		SELECT user.username, count(creditCardNum) as creditCardCount,CONCAT(IF(customer.username IS NOT NULL AND employee.username IS NOT NULL, 'CustomerManager',''),IF(customer.username IS NOT NULL AND employee.username IS NULL AND admin.username IS NULL, 'Customer',''),IF(customer.username IS NOT NULL AND admin.username IS NOT NULL, 'CustomerAdmin',''),IF(user.userType='User', 'User',''),IF(customer.username IS NULL AND employee.username IS NOT NULL, 'Manager',''),IF(customer.username IS NULL AND admin.username IS NOT NULL, 'Admin','')) AS userType, status
		FROM user LEFT JOIN customercreditcard on user.username=customercreditcard.username LEFT JOIN employee ON user.username=employee.username LEFT JOIN admin ON user.username=admin.username LEFT JOIN customer ON user.username=customer.username
		WHERE (i_username='' OR user.username=i_username) AND (status=IF(i_status='ALL', status , i_status))
		GROUP BY user.username
        ORDER BY creditCardCount DESC;
	ELSE
		DROP TABLE IF EXISTS AdFilterUser;
		CREATE TABLE AdFilterUser
		SELECT user.username, count(creditCardNum) as creditCardCount,CONCAT(IF(customer.username IS NOT NULL AND employee.username IS NOT NULL, 'CustomerManager',''),IF(customer.username IS NOT NULL AND employee.username IS NULL AND admin.username IS NULL, 'Customer',''),IF(customer.username IS NOT NULL AND admin.username IS NOT NULL, 'CustomerAdmin',''),IF(user.userType='User', 'User',''),IF(customer.username IS NULL AND employee.username IS NOT NULL, 'Manager',''),IF(customer.username IS NULL AND admin.username IS NOT NULL, 'Admin','')) AS userType, status
		FROM user LEFT JOIN customercreditcard on user.username=customercreditcard.username LEFT JOIN employee ON user.username=employee.username LEFT JOIN admin ON user.username=admin.username LEFT JOIN customer ON user.username=customer.username
		WHERE (i_username='' OR user.username=i_username) AND (status=IF(i_status='ALL', status , i_status))
		GROUP BY user.username
        ORDER BY creditCardCount ASC;
	END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_view_comDetail_emp` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_view_comDetail_emp`(IN i_comName VARCHAR(50))
BEGIN
    DROP TABLE IF EXISTS AdComDetailEmp;
    CREATE TABLE AdComDetailEmp
	SELECT firstName AS empFirstname, lastName AS empLastname FROM user JOIN manager USING (username)
    WHERE comName=i_comName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `admin_view_comDetail_th` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `admin_view_comDetail_th`(IN i_comName VARCHAR(50))
BEGIN
    DROP TABLE IF EXISTS AdComDetailTh;
    CREATE TABLE AdComDetailTh
	SELECT thName, manUsername as thManagerUsername, thCity, thState, capacity AS thCapacity FROM theater
    WHERE comName=i_comName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_add_creditcard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_add_creditcard`(IN i_username VARCHAR(50), IN i_creditCardNum CHAR(16))
BEGIN
	IF (i_username, 5) IN (SELECT username, COUNT(*) as cardcount FROM customercreditcard GROUP BY username HAVING cardcount>4) THEN
		SIGNAL SQLSTATE '45000' SET Message_Text='Maximum creditcards registered';
	ELSE IF NOT length(i_creditCardNum)=16 THEN
		SIGNAL SQLSTATE '45000' SET message_text='Invalid creditCard';
    ELSE
		INSERT INTO CustomerCreditCard(creditCardNum, username) VALUES (i_creditCardNum, i_username);
	END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_filter_mov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_filter_mov`(IN i_movName VARCHAR(50), IN i_comName VARCHAR(50), IN i_city VARCHAR(50), IN i_state VARCHAR(50), IN i_minMovPlayDate DATE, i_maxMovPlayDate DATE)
BEGIN
    DROP TABLE IF EXISTS CosFilterMovie;
    CREATE TABLE CosFilterMovie
	SELECT movName, thName, thStreet, thCity, thState, thZipCode, movieplay.comName, movPlayDate, movReleaseDate
    FROM movieplay JOIN theater USING (thName, comName)
    WHERE
		(i_movName='ALL' OR movName=i_movName) AND
        (i_comName='ALL' OR theater.comName=i_comName) AND
        (i_city='' OR thCity=i_city) AND
        (i_state='' OR i_state='ALL' OR thState=i_state) AND
        (i_minMovPlayDate IS NULL OR i_minMovPlayDate<=movPlayDate) AND
        (i_maxMovPlayDate IS NULL OR i_maxMovPlayDate>=movPlayDate);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_only_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_only_register`(IN i_username VARCHAR(50), IN i_password VARCHAR(50), IN i_firstname VARCHAR(50), IN i_lastname VARCHAR(50))
BEGIN
	INSERT INTO user (username, password, firstname, lastname, userType) VALUES (i_username, MD5(i_password), i_firstname, i_lastname, 'Customer');
	INSERT INTO customer (username) VALUES (i_username);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_view_history` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_view_history`(IN i_cusUsername VARCHAR(50))
BEGIN
    DROP TABLE IF EXISTS CosViewHistory;
    CREATE TABLE CosViewHistory
	SELECT movName, thName, comName, creditCardNum, movPlayDate FROM customercreditcard JOIN customerviewmovie USING (creditCardNum)
    WHERE username=i_cusUsername;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `customer_view_mov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `customer_view_mov`(IN i_creditCardNum CHAR(16), IN i_movName VARCHAR(50), i_movReleaseDate DATE,i_thName VARCHAR(50), i_comName VARCHAR(50), i_movPlayDate DATE)
BEGIN
	IF (i_movPlayDate, 3) IN (select movPlayDate, count(username) AS daycount From customerviewmovie JOIN customercreditcard USING (creditCardNum) WHERE username=(select username from customercreditcard WHERE creditCardNum=i_creditCardNum) GROUP BY movPlayDate HAVING daycount>2) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT= 'Already Viewed Three Movies This Day';
    ELSE IF i_movReleaseDate>=i_movPlayDate THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT= 'PlayDate Before ReleaseDate';
	ELSE
		INSERT INTO customerviewmovie(creditCardNum, thName, comName,movName, movReleaseDate, movPlayDate) VALUES(i_creditCardNum, i_thName, i_comName, i_movName, i_movReleaseDate, i_movPlayDate);
	END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `manager_customer_add_creditcard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `manager_customer_add_creditcard`(IN i_username VARCHAR(50), IN i_creditCardNum CHAR(16))
BEGIN
	IF (i_username, 5) IN (SELECT username, COUNT(*) as cardcount FROM customercreditcard GROUP BY username HAVING cardcount>4) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Maximum creditcards registered';
	ELSE
		INSERT INTO customercreditcard(creditCardNum, username) VALUES (i_creditCardNum, i_username);
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `manager_customer_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `manager_customer_register`(IN i_username VARCHAR(50), IN i_password VARCHAR(50), IN i_firstname VARCHAR(50), IN i_lastname VARCHAR(50), IN i_comName VARCHAR(50), IN i_empStreet VARCHAR(50), IN i_empCity VARCHAR(50), IN i_empState CHAR(2), IN i_empZipcode CHAR(5))
BEGIN
	INSERT INTO user(username, password, firstName, lastName, userType) VALUES (i_username, md5(i_password), i_firstname, i_lastname, 'Employee, Customer');
    INSERT INTO employee(username) VALUES (i_username);
	INSERT INTO Manager(username, comName, manStreet, manCity, manState, manZipcode) VALUES (i_username, i_comName, i_empStreet, i_empCity, i_empState, i_empZipcode);
	INSERT INTO Customer(username) VALUES (i_username);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `manager_filter_th` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `manager_filter_th`(IN i_manUsername VARCHAR(50), IN i_movName VARCHAR(50), IN i_minMovDuration INT(11), IN i_maxMovDuration INT(11), IN i_minMovReleaseDate DATE, IN i_maxMovReleaseDate DATE, IN i_minMovPlayDate DATE, IN i_maxMovPlayDate DATE, IN i_includeNotPlayed BOOLEAN)
BEGIN
	DROP TABLE IF EXISTS ManFilterTh;
    IF i_includeNotPlayed IS TRUE THEN
		CREATE TABLE ManFilterTh
		SELECT movName, duration as movDuration, movReleaseDate, movPlayDate
		FROM movie JOIN theater LEFT JOIN movieplay USING (thName, movName, comName, movReleaseDate)
        WHERE
			(manUsername=i_manUsername) AND
			(i_movName='' OR movName=i_movName) AND
			(i_minMovDuration IS NULL OR i_minMovDuration<=duration) AND
			(i_maxMovDuration IS NULL OR i_maxMovDuration>=duration) AND
			(i_minMovReleaseDate IS NULL OR i_minMovReleaseDate<=movReleaseDate) AND
			(i_maxMovReleaseDate IS NULL OR i_maxMovReleaseDate>=movReleaseDate) AND
			(i_minMovPlayDate IS NULL OR i_minMovPlayDate<=movPlayDate) AND
			(i_maxMovPlayDate IS NULL OR i_maxMovPlayDate>=movPlayDate) AND
            (movPlayDate IS NULL);
    ELSE
		CREATE TABLE ManFilterTh
		SELECT movName, duration as movDuration, movReleaseDate, movPlayDate
		FROM movie JOIN theater LEFT JOIN movieplay USING (thName, movName, comName, movReleaseDate)
		WHERE
			(manUsername=i_manUsername) AND
			(i_movName='' OR movName=i_movName) AND
			(i_minMovDuration IS NULL OR i_minMovDuration<=duration) AND
			(i_maxMovDuration IS NULL OR i_maxMovDuration>=duration) AND
			(i_minMovReleaseDate IS NULL OR i_minMovReleaseDate<=movReleaseDate) AND
			(i_maxMovReleaseDate IS NULL OR i_maxMovReleaseDate>=movReleaseDate) AND
			(i_minMovPlayDate IS NULL OR i_minMovPlayDate<=movPlayDate) AND
			(i_maxMovPlayDate IS NULL OR i_maxMovPlayDate>=movPlayDate);
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `manager_only_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `manager_only_register`(IN i_username VARCHAR(50), IN i_password VARCHAR(50), IN i_firstname VARCHAR(50), IN i_lastname VARCHAR(50), IN i_comName VARCHAR(50), IN i_empStreet VARCHAR(50), IN i_empCity VARCHAR(50), IN i_empState CHAR(2), IN i_empZipcode CHAR(5))
BEGIN
	Insert INTO user(username, password, firstName, lastName, userType) VALUES (i_username, md5(i_password), i_firstname, i_lastname, 'Employee');
	Insert INTO employee(username) VALUES (i_username);
	INSERT INTO Manager(username, comNAME, manStreet, manCity, manState, manZipcode) VALUES (i_username, i_comName, i_empStreet, i_empCity, i_empState, i_empZipcode);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `manager_schedule_mov` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `manager_schedule_mov`(IN i_manUsername VARCHAR(50), IN i_movName VARCHAR(50), i_movReleaseDate DATE, i_movPlayDate DATE)
BEGIN
	 IF i_movReleaseDate<=i_movPlayDate THEN
		INSERT INTO movieplay(thName, comName,movName, movReleaseDate, movPlayDate) SELECT thName, comName, i_movName, i_movReleaseDate, i_movPlayDate FROM theater WHERE manUsername=i_manUsername;
	ELSE
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT= 'PlayDate Before ReleaseDate';
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_filter_th` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_filter_th`(IN i_thName VARCHAR(50), IN i_comName VARCHAR(50), IN i_city VARCHAR(50), IN i_state VARCHAR(3))
BEGIN
    DROP TABLE IF EXISTS UserFilterTh;
    CREATE TABLE UserFilterTh
	SELECT thName, thStreet, thCity, thState, thZipcode, comName
    FROM Theater
    WHERE
		(thName = i_thName OR i_thName = "ALL") AND
        (comName = i_comName OR i_comName = "ALL") AND
        (thCity = i_city OR i_city = "") AND
        (thState = i_state OR i_state='ALL' OR i_state = "");
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_filter_visitHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_filter_visitHistory`(IN i_username VARCHAR(50), IN i_minVisitDate DATE, IN i_maxVisitDate DATE)
BEGIN
    DROP TABLE IF EXISTS UserVisitHistory;
    CREATE TABLE UserVisitHistory
	SELECT thName, thStreet, thCity, thState, thZipCode, comName, visitDate
    FROM uservisittheater
		NATURAL JOIN
        theater
	WHERE
		(username = i_username) AND
        (i_minVisitDate IS NULL OR visitDate >= i_minVisitDate) AND
        (i_maxVisitDate IS NULL OR visitDate <= i_maxVisitDate);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_login`(IN i_username VARCHAR(50), IN i_password VARCHAR(50))
BEGIN
    DROP TABLE IF EXISTS UserLogin;
    CREATE TABLE UserLogin
	SELECT user.username, user.status, IF(user.userType in ('Customer','Employee, Customer'), 1, 0) as isCustomer, IF(user.username in (Admin.username), 1, 0) as isAdmin, IF(user.username in (Manager.username), 1, 0) as isManager
    FROM user LEFT JOIN Manager on user.username=manager.username LEFT JOIN Admin on user.username=Admin.username
    WHERE
		(user.username = i_username) AND
        (user.password = i_password);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_register` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_register`(IN i_username VARCHAR(50), IN i_password VARCHAR(50), IN i_firstname VARCHAR(50), IN i_lastname VARCHAR(50))
BEGIN
		INSERT INTO user (username, password, firstname, lastname) VALUES (i_username, MD5(i_password), i_firstname, i_lastname);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `user_visit_th` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_visit_th`(IN i_thName VARCHAR(50), IN i_comName VARCHAR(50), IN i_visitDate DATE, IN i_username VARCHAR(50))
BEGIN
    INSERT INTO uservisittheater (thName, comName, visitDate, username, visitID)
    SELECT i_thName, i_comName, i_visitDate, i_username, COUNT(*)+1 FROM uservisittheater;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 15:24:12
